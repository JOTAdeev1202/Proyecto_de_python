def menu_principal():
    print("#############################################")
    print("### BIENVENIDOS AL SISTEMA DE CAMPUSLANDS ###")
    print("#############################################")
    print("")
    print("#############################################")
    print("### seleccione una opcion segun su rol   ###")
    print("#############################################")
    print("""""""""""""""""""""""""""
            1- menu coordinador
            2- menu trainer
            3- menu camper
 
           """"""""""""""""""""""""""""")
    opcion_principal = int()
def menu_coordinador():
    print("#############################################")
    print("###          menu coordinador            ###")
    print("#############################################")
    print("")
    print("---------- seleccione una opcion ----------")
    print("""""""""""""""""""""""""""
            1- registrar camper
            2- asignar notas al camper
            3- cambiar estado de admision al camper
            4- asignar ruta al camper
            5- asignar camper a una ruta
            6- asignar horarios al profesor
            0- regresar al menu principal
 
           """"""""""""""""""""""""""""")
    
def menu_trainer():
    print("#############################################")
    print("###          menu trainer            ###")
    print("#############################################")
    print("")
    print("---------- seleccione una opcion ----------")
    print("""""""""""""""""""""""""""
            1- mirar campers asignados a su ruta
            2- mirar horarios de clases
            3- registrar notas de seguimiento
            4- ver listado de campers segun el riesgo en el que estan
            0- para salir al menu principal
           """"""""""""""""""""""""""""")
    
def menu_camper():
    print("#############################################")
    print("###             menu camper              ###")
    print("#############################################")
    print("")
    print("---------- seleccione una opcion ----------")
    print("""""""""""""""""""""""""""
            1- ver notas de seguimiento
            2- ver horario de clases
            3- ver la ruta a la que pertenece
            4- ver estado en el que se encuentra
            0- para salir al menu principal
 
           """"""""""""""""""""""""""""")
