def campers_asignados():
    print