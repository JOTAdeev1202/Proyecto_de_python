from principal import lista_de_campers

def ver_notas_camper():
    print

def ver_horario_camper():
    print

def ver_ruta_Camper():
    print

def ver_riesgo_camper():
    print
    
