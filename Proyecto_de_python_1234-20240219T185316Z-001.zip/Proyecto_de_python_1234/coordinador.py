import random

from principal import lista_de_campers

#funcion para registrar los datos de un camper
def registroCamper():
    
    nro_de_identificacion = int(input('digite el numero de identificaicon del camper: '))
    nombre_camper = input('digite el nombre del camper: ')
    apellidos_camper = input('digite los apellidos del camper: ')
    direccion = input('digite la direccion del camper: ')
    acudiente = input('digite el nombre del acudiente: ')
    numero_celular = int(input('digite el numero de celular  del camper: '))
    telefono_fijo = int(input('digite el telefono fijo del camper: '))

    directorio_campers = {

        'nro de identificacion' : nro_de_identificacion ,
        'nombre' : nombre_camper ,
        'apellidos' : apellidos_camper ,
        'direccion' : direccion ,
        'acudiente' : acudiente ,
        'celular' : numero_celular ,
        'fijo' : telefono_fijo

    }
    return directorio_campers

#funcion para saber si es admitido el camper segun el promedio de sus notas
def resultado_prueba_admision():
        porcentaje_de_teoria = 0.4
        porcentaje_de_practica = 0.6
        global nota_minima
        nota_minima = 60
        global promedio

        for iterador in lista_de_campers:

            nota_teoria = int(input(f'Digite la nota de teoría para {iterador["nombre"]}: '))
            nota_practica = int(input(f'Digite la nota de práctica para {iterador["nombre"]}: '))

            promedio = (nota_teoria * porcentaje_de_teoria) + (nota_practica * porcentaje_de_practica)
            iterador['nota_teoria'] = nota_teoria
            iterador['nota_practica'] = nota_practica
            iterador['promedio'] = promedio
            iterador['aprobo_prueba'] = promedio >= nota_minima

            if promedio >= nota_minima:
                print(f"la nota del camper {iterador['nombre']}  {iterador['apellidos']} fue {promedio}, y aprobo la prueba de admision")
            
            else:
                print(f"la nota del camper {iterador['nombre']} {iterador['apellidos']} fue {promedio} por ende no aprobo la prueba de admision")

def cambiar_estado_campers():
    print

def registro_grupos_entrenamiento():

    rutas_de_entrenamiento = ('Node js','Java','Netcore')
    contador_rutas = {rutas: 0 for rutas in rutas_de_entrenamiento}
    
    for camper in lista_de_campers:
        promedio = camper.get('promedio',0)

        if promedio >= 60:       
            for asignacion_ruta in lista_de_campers:
                ruta_asignada = random.choice(rutas_de_entrenamiento)
                asignacion_ruta['rutas'] = ruta_asignada
                contador_rutas [ruta_asignada] +=1
        else:
            print(f"la nota del camper {camper['nombre']}  {camper['apellidos']} fue {promedio} por ende no aprobo la prueba de admision")
    
    return contador_rutas

def registrar_trainer():
    print