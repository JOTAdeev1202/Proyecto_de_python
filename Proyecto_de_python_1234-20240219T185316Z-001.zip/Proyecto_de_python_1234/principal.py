#creal la lista para almacenar cada camper en un indice

import coordinador

import campers

import trainers

import menus

lista_de_campers = []

menus.menu_principal()
menus.menu_coordinador()
"""
#condicional para agregar n campers hasta que cancelemos el proceso
while True:
    
    directorio_campers = registroCamper()
    lista_de_campers.append(directorio_campers)
    
    comprobacion = input('quiere registrar otr usuario si/no: ')
    if comprobacion.lower() != 'si':
       break

print('campers registrados :')
#iterador para recorrer cada indice de la liste y mostrar los campers registrados
for iterador in lista_de_campers:
    print(iterador)

#print para mostrar la nota y saber si aprobo o no
print(resultado_prueba_admision(lista_de_campers))

manejo_control = registro_grupos_entrenamiento(lista_de_campers)

print('rutas asignadas: ')
for camper in lista_de_campers:
    print(f"{camper['nombre']} {camper['apellidos']} - Ruta: {camper['rutas']}")

print('conteo de campers por ruta: ')
for rutas, conteo in manejo_control.items():
    print(f"{rutas}:{conteo}")

"""