import json

def cargar_datos():
    try:
        with open('data.json', 'r') as archivo:
            datos = json.load(archivo)
    except FileNotFoundError:
        datos = []
    return datos

def guardar_datos(datos):
    with open('data.json', 'w') as archivo:
        json.dump(datos, archivo, indent=2)

def mostrar_datos():
    datos = cargar_datos()
    if datos:
        for indice, elemento in enumerate(datos, start=1):
            print(f"{indice}. {elemento}")
    else:
        print("No hay datos disponibles.")

def agregar_elemento(elemento):
    datos = cargar_datos()
    datos.append(elemento)
    guardar_datos(datos)
    print(f"Elemento '{elemento}' agregado correctamente.")

def actualizar_elemento(indice, nuevo_valor):
    datos = cargar_datos()
    if 1 <= indice <= len(datos):
        datos[indice - 1] = nuevo_valor
        guardar_datos(datos)
        print(f"Elemento actualizado en la posición {indice}.")
    else:
        print("Índice fuera de rango. No se pudo actualizar el elemento.")

def eliminar_elemento(indice):
    datos = cargar_datos()
    if 1 <= indice <= len(datos):
        elemento_eliminado = datos.pop(indice - 1)
        guardar_datos(datos)
        print(f"Elemento '{elemento_eliminado}' eliminado correctamente.")
    else:
        print("Índice fuera de rango. No se pudo eliminar el elemento.")

# Ejemplo de uso
while True:
    print("\n1. Mostrar Datos")
    print("2. Agregar Elemento")
    print("3. Actualizar Elemento")
    print("4. Eliminar Elemento")
    print("5. Salir")

    opcion = input("Seleccione una opción (1-5): ")

    if opcion == '1':
        mostrar_datos()
    elif opcion == '2':
        nuevo_elemento = input("Ingrese el nuevo elemento: ")
        agregar_elemento(nuevo_elemento)
    elif opcion == '3':
        mostrar_datos()
        indice_actualizar = int(input("Ingrese el índice del elemento a actualizar: "))
        nuevo_valor = input("Ingrese el nuevo valor: ")
        actualizar_elemento(indice_actualizar, nuevo_valor)
    elif opcion == '4':
        mostrar_datos()
        indice_eliminar = int(input("Ingrese el índice del elemento a eliminar: "))
        eliminar_elemento(indice_eliminar)
    elif opcion == '5':
        print("Saliendo del programa. ¡Hasta luego!")
        break
    else:
        print("Opción no válida. Por favor, seleccione una opción válida (1-5).")

